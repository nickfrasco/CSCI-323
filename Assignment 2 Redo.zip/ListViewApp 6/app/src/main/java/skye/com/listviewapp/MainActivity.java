package skye.com.listviewapp;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Data> dataModels= new ArrayList<>();
    ListView listView;
    public static CustomAdapter adapter;
    FloatingActionButton add , delete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        listView = findViewById(R.id.list);
        adapter = new CustomAdapter(dataModels,getApplicationContext());

        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Data dataModel= dataModels.get(position);
                dataModel.setStatus("Deleted");
                AddItem.dataModelsAddedorDeleted.add(dataModel);
                Snackbar.make(view, "The Item Removed: "+dataModel.getName()+"\n", Snackbar.LENGTH_LONG)
                        .setAction("No action", null).show();
                dataModels.remove(dataModel);
                adapter.notifyDataSetChanged();

            }
        });

        add = findViewById(R.id.fab);
        delete = findViewById(R.id.delete);
        delete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (dataModels.isEmpty()){
                            Toast.makeText(getApplicationContext(),"The List is Empty",Toast.LENGTH_LONG).show();
                        }else {
                            dataModels.remove(0);
                            adapter.notifyDataSetChanged();
                        }

                    }
                }
        );
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), AddItem.class));
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}