package skye.com.listviewapp;

public class Data {

    String name;
    String quantity;
    String Status;

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public Data(String name, String quantity ) {
        this.name=name;
        this.quantity=quantity;
    }

    public String getName() {
        return this.name;
    }

    public String getQuantity() {
        return this.quantity;
    }

    @Override
    public String toString() {
        return "Data modified = {" +
                "name ='" + name + '\'' +
                ", quantity='" + quantity + '\'' +
                ", Status='" + Status + '\'' +
                '}';
    }
}