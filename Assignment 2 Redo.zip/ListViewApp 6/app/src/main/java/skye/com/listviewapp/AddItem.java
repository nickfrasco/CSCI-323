package skye.com.listviewapp;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AddItem extends AppCompatActivity {


    Button add;
    Button datalog;
    EditText name;
    EditText quantity;
    List<Data>  dataModels = MainActivity.dataModels;
    public static  List<Data>  dataModelsAddedorDeleted = new ArrayList<>();
    String data = "";
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.additems);
        add = findViewById(R.id.add);
        datalog = findViewById(R.id.datalog);

        name = findViewById(R.id.name);
        quantity = findViewById(R.id.quantity);
        add.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Data data  = new Data(name.getText().toString(),quantity.getText().toString());
                        data.setStatus("Added");
                        dataModelsAddedorDeleted.add(data);
                        dataModels.add(data);
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish();
                    }
                }
        );

        datalog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dataModels.isEmpty()&&dataModelsAddedorDeleted.isEmpty()){
                    Toast.makeText(getApplicationContext(),"The List is Empty",Toast.LENGTH_LONG).show();
                }else {
                    data = "The Items are: ";
                    for (Data dd : dataModelsAddedorDeleted){
                        data = data+dd.toString() +"\n";
                    }

                    // createcontactdialog dialog
                    final Dialog dialog = new Dialog(AddItem.this);
                    dialog.setContentView(R.layout.dialog);
                    dialog.setTitle("All Data Altered...");

                    // set the create contact dialog  components - text, image and button
                    TextView text = dialog.findViewById(R.id.text);

                    text.setText(data);

                    Button dialogButton = dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the createcontactdialog dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });

                    dialog.show();

                }

            }
        });

    }
}
