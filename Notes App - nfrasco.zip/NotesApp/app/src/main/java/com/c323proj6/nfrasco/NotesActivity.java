package com.c323proj6.nfrasco;

import android.app.SearchManager;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.c323proj6.nfrasco.adapters.NoteAdapter;
import com.c323proj6.nfrasco.models.Note;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class NotesActivity extends AppCompatActivity {

    private RecyclerView notes_list;
    private List<Note> notes;
    private NoteAdapter adapter;
    private SQLiteDatabase liteDatabase;
    private SearchView searchView;
    public TextView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        liteDatabase = openOrCreateDatabase(MainActivity.DB_NAME, Context.MODE_PRIVATE,null);
        initUI();
    }

    private void retreiveAllNotes(){
        Cursor cursorNotes = liteDatabase.rawQuery("SELECT * FROM "+MainActivity.TABLE_NAME, null);
        if(cursorNotes.moveToFirst()){
            do{
                Note note = new Note();
                note.setID(cursorNotes.getInt(0));
                note.setNote_id(String.valueOf(cursorNotes.getInt(0)));
                note.setNote_text(cursorNotes.getString(1));
                note.setNote_date(cursorNotes.getString(2));
                note.setNote_location(cursorNotes.getString(3));
                note.setColorList(cursorNotes.getInt(4));
                notes.add(note);
            }while (cursorNotes.moveToNext());
            cursorNotes.close();
            adapter = new NoteAdapter(NotesActivity.this,notes,liteDatabase,message);
            notes_list.setAdapter(adapter);
        }
    }

    private void initUI(){
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.toolbar_title);
        setSupportActionBar(toolbar);

        notes_list = findViewById(R.id.notes_list);
        notes_list.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        notes_list.setItemAnimator(new DefaultItemAnimator());
        notes = new ArrayList<>();
        message = findViewById(R.id.txt_empty);
        retreiveAllNotes();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        SearchManager manager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_settings).getActionView();
        searchView.setSearchableInfo(manager.getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.getFilter().filter(query);

                if(adapter.notes.size() == 0){

                    message.setVisibility(View.VISIBLE);
                }else {
                    //Toast.makeText(NotesActivity.this, "Searching"+notes.size(), Toast.LENGTH_SHORT).show();
                    message.setVisibility(View.GONE);
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                if(adapter.notes.size() == 0){
                    message.setVisibility(View.VISIBLE);
                }else {
                    //Toast.makeText(NotesActivity.this, "Searching"+notes.size(), Toast.LENGTH_SHORT).show();
                    message.setVisibility(View.GONE);
                }
                return true;
            }
        });

        return true;
    }

    @Override
    public void onBackPressed() {
        // close search view on back button pressed
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }
        super.onBackPressed();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
