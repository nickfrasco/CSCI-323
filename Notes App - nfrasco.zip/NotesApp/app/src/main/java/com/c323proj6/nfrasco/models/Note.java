package com.c323proj6.nfrasco.models;

import java.io.Serializable;

public class Note implements Serializable {
    private String note_text, note_date, note_location, note_id;
    private int colorList;
    private int ID;


    public Note() {
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNote_text() {
        return note_text;
    }

    public int getColorList() {
        return colorList;
    }

    public void setColorList(int colorList) {
        this.colorList = colorList;
    }

    public void setNote_text(String note_text) {
        this.note_text = note_text;
    }

    public String getNote_date() {
        return note_date;
    }

    public void setNote_date(String note_date) {
        this.note_date = note_date;
    }

    public String getNote_location() {
        return note_location;
    }

    public void setNote_location(String note_location) {
        this.note_location = note_location;
    }

    public String getNote_id() {
        return note_id;
    }

    public void setNote_id(String note_id) {
        this.note_id = note_id;
    }
}
