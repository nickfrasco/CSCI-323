package com.c323proj6.nfrasco.adapters;

import android.content.Context;
//import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
//import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.c323proj6.nfrasco.MainActivity;
//import com.c323proj6.nfrasco.NotesActivity;
import com.c323proj6.nfrasco.R;
import com.c323proj6.nfrasco.models.Note;
//import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteView> implements Filterable {
    public class NoteView extends RecyclerView.ViewHolder{
        private CardView noteCard;
        private TextView noteText, noteDate, noteLocation;
        private AppCompatImageView close;

        public NoteView(@NonNull View itemView) {
            super(itemView);
            noteCard = itemView.findViewById(R.id.note_card);
            noteText = itemView.findViewById(R.id.txt_note_content);
            noteDate = itemView.findViewById(R.id.txt_note_date);
            noteLocation = itemView.findViewById(R.id.txt_note_location);
            close = itemView.findViewById(R.id.img_delete);
        }
    }

    private Context context;
    public List<Note> notes;
    private List<Note> filteredNotes;
    private SQLiteDatabase database;
    private TextView VIEW;

    public NoteAdapter(Context context, List<Note> notes, SQLiteDatabase database
    ,TextView VIEW) {
        this.context = context;
        this.notes = notes;
        this.filteredNotes = notes;
        this.database = database;
        this.VIEW = VIEW;
    }

    @NonNull
    @Override
    public NoteView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NoteView(LayoutInflater.from(context).inflate(R.layout.notes_row,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull NoteView holder, int position) {
        final Note note = filteredNotes.get(position);
        holder.noteLocation.setText(note.getNote_location());
        holder.noteDate.setText(note.getNote_date());
        holder.noteText.setText(note.getNote_text());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            switch (note.getColorList()) {
                case 1:
                    holder.noteCard.setBackgroundColor(context.getResources().getColor(android.R.color.holo_blue_light));
                    break;
                case 2:
                    holder.noteCard.setBackgroundColor(context.getResources().getColor(android.R.color.holo_green_light));
                    break;
                case 3:
                    holder.noteCard.setBackgroundColor(context.getResources().getColor(android.R.color.holo_purple));
                    break;
                case 4:
                    holder.noteCard.setBackgroundColor(context.getResources().getColor(android.R.color.holo_red_light));
                    break;
                case 5:
                    holder.noteCard.setBackgroundColor(context.getResources().getColor(android.R.color.holo_orange_light));
                    break;
            }
        }
        holder.close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                String deleteQuery = "DELETE FROM "+ MainActivity.TABLE_NAME +" WHERE id = ?;";
                database.execSQL(deleteQuery,new Object[]{note.getID()});
                notes.clear();
                reloadDatabase();
            }
        });
    }

    private void reloadDatabase(){
        Cursor cursorNotes = database.rawQuery("SELECT * FROM "+ MainActivity.TABLE_NAME, null);
        if(cursorNotes.moveToFirst()){
            do{
                Note note = new Note();
                note.setID(cursorNotes.getInt(0));
                note.setNote_id(String.valueOf(cursorNotes.getInt(0)));
                note.setNote_text(cursorNotes.getString(1));
                note.setNote_date(cursorNotes.getString(2));
                note.setNote_location(cursorNotes.getString(3));
                note.setColorList(cursorNotes.getInt(4));
                notes.add(note);
            }while (cursorNotes.moveToNext());
            cursorNotes.close();
            notifyDataSetChanged();
        }
    }

    @Override
    public int getItemCount() {
        if(filteredNotes.size() == 0){
            VIEW.setVisibility(View.VISIBLE);
        }else {
            VIEW.setVisibility(View.GONE);
        }
        return filteredNotes.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if(charString.isEmpty()){
                    filteredNotes = notes;
                }else {
                    List<Note> filter = new ArrayList<>();
                    for (Note row: notes){
                        if(row.getNote_location().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getNote_date().toLowerCase().contains(charString.toLowerCase())){
                            filter.add(row);
                        }
                    }

                    filteredNotes = filter;
                }
                FilterResults results = new FilterResults();
                results.values = filteredNotes;
                return results;
            }
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                filteredNotes = (ArrayList<Note>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }
}
