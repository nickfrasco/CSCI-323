package com.c323proj6.nfrasco;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private EditText edt_text;
    private ImageView blue,green,purple,red,yellow;
    private Button btn_add_note;
    private TextView location_text;
    private int colorList = 0;
    private LocationManager locationManager;
    private double lat = 0.0;
    private double lon = 0.0;
    private SQLiteDatabase liteDatabase;
    public static String TABLE_NAME = "notes_app_table";
    public static String DB_NAME = "notes_app_db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        liteDatabase = openOrCreateDatabase(DB_NAME,Context.MODE_PRIVATE,null);
        createNoteTable();
        initUI();
    }

    private void initUI(){

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.toolbar_title);
        setSupportActionBar(toolbar);

        blue = findViewById(R.id.blue_circle);
        green = findViewById(R.id.green_circle);
        purple = findViewById(R.id.purple_circle);
        red = findViewById(R.id.red_circle);
        yellow = findViewById(R.id.yellow_circle);

        edt_text = findViewById(R.id.edt_note);
        btn_add_note = findViewById(R.id.btn_add_note);
        location_text = findViewById(R.id.txt_location);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,NotesActivity.class));
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            edt_text.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(),android.R.color.holo_blue_light));
            colorList = 1;
        }

        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    edt_text.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(),android.R.color.holo_blue_light));
                    colorList = 1;
                }
            }
        });
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    edt_text.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(),android.R.color.holo_green_light));
                    colorList = 2;
                }
            }
        });
        purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    edt_text.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(),android.R.color.holo_purple));
                    colorList = 3;
                }
            }
        });
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    edt_text.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(),android.R.color.holo_red_light));
                    colorList = 4;
                }
            }
        });
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    edt_text.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(),android.R.color.holo_orange_light));
                    colorList = 5;
                }
            }
        });
        btn_add_note.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edt_text.getText().toString().isEmpty()){
                    Snackbar.make(view,"Fill in note first!",Snackbar.LENGTH_SHORT).show();
                }else{
                    addNote(edt_text.getText().toString(),
                            getCurrentDate(),
                            location_text.getText().toString(),
                            colorList);
                    edt_text.setText("");
                    Snackbar.make(view,"Note Added Successfully!",Snackbar.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void createNoteTable(){
        String createTable = "CREATE TABLE IF NOT EXISTS "+
                TABLE_NAME+
                "(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"+
                "note_text TEXT NOT NULL,"+
                "note_date TEXT NOT NULL,"+
                "note_location TEXT NOT NULL,"+
                "note_color int NOT NULL);";
        liteDatabase.execSQL(createTable);
    }

    private void addNote(String note_text, String note_date,
                         String note_location, int note_color){
        String addNote = "INSERT INTO  "+
                TABLE_NAME+
                "(note_text,note_date,note_location,note_color)"+
                "VALUES "+
                "(?,?,?,?);";
        Object [] args = {note_text,note_date,note_location,note_color};
        liteDatabase.execSQL(addNote,args);

    }

    private String getCurrentDate(){
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        return df.format(c);
    }

    @Override
    protected void onStart() {
        super.onStart();
        requestLocationPermission();
        checkGPSEnabled();
    }

    private void requestLocationPermission(){
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},150);
        }else{
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,MainActivity.this);

        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 150 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,MainActivity.this);
        }
    }

    private void checkGPSEnabled(){
        if( !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.gps_not_found_title)  // GPS not found
                    .setMessage(R.string.gps_not_found_message) // Want to enable?
                    .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            MainActivity.this.startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        }
                    })
                    .setNegativeButton(R.string.no, null)
                    .show();
        }
    }


    @Override
    public void onLocationChanged(Location location) {
        lat = location.getLatitude();
        lon = location.getLongitude();

        try {

            Geocoder geo = new Geocoder(this.getApplicationContext(), Locale.getDefault());
            List<Address> addresses = geo.getFromLocation(lat, lon, 1);
            if (addresses.isEmpty()) {
                location_text.setText(getString(R.string.waiting_for_location));
            }
            else {
                addresses.size();
                location_text.setText(addresses.get(0).getLocality() +", " + addresses.get(0).getAdminArea());
            }
        }catch (IOException exc){
            exc.printStackTrace();
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
