package com.example.assignment3;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;

import android.os.Bundle;
import android.os.*;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.util.*;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;



public class MainActivity extends AppCompatActivity {

    private List<MyMovie> myMovieList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        populateMyMovies();
        populateCustomListView();



    }

    private void populateMyMovies() {
        myMovieList.add(new MyMovie( "The Dark Knight", "2008", R.drawable.dark_knight));
        myMovieList.add(new MyMovie( "Forrest Gump", "1994", R.drawable.forest_gump));
        myMovieList.add(new MyMovie( "Back to the Future", "1985", R.drawable.back_to_the_future));
        myMovieList.add(new MyMovie( "Titanic", "1997", R.drawable.titanic));
    }

    private void populateCustomListView() {
        ArrayAdapter<MyMovie> adapter = new MyListAdapter();
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), theDarkKnight.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), forrestGump.class);
                    startActivityForResult(myIntent, 1);
                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), backToTheFuture.class);
                    startActivityForResult(myIntent, 2);
                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), titanic.class);
                    startActivityForResult(myIntent, 3);
                }
            }
        });


    }

    public void onFavButtonClick(View view) {
        Intent intent = new Intent(MainActivity.this, favoritesPage.class);
        startActivityForResult(intent, 40);
    }

    private class MyListAdapter extends ArrayAdapter<MyMovie> {
        public MyListAdapter() {
            super(MainActivity.this, R.layout.item_layout, myMovieList);
        }


        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {


            View itemView = convertView;

            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.item_layout, parent, false);

            MyMovie currentMovie = myMovieList.get(position);

            TextView itemName = itemView.findViewById(R.id.item_Name);
            itemName.setText(currentMovie.getMovieName());
            TextView itemYear = itemView.findViewById(R.id.item_Year);
            itemYear.setText(currentMovie.getMovieYear());
            ImageView itemIcon = itemView.findViewById(R.id.item_Icon);
            itemIcon.setImageResource(currentMovie.getMovieIcon());
            return itemView;



            //return super.getView(position, convertView, parent);
        }
    }
    }




