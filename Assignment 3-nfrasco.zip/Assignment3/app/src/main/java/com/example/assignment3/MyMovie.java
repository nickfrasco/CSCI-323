package com.example.assignment3;

public class MyMovie {
    private String movieName;
    private String movieYear;
    private int movieIcon;

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieYear() {
        return movieYear;
    }

    public void setMovieYear(String movieYear) {
        this.movieYear = movieYear;
    }

    public int getMovieIcon() {
        return movieIcon;
    }

    public void setMovieIcon(int movieIcon) {
        this.movieIcon = movieIcon;
    }

    public MyMovie (String movieName, String movieYear, int movieIcon){
        this.movieName = movieName;
        this.movieYear = movieYear;
        this.movieIcon = movieIcon;

    }
}
