package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class titanic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_titanic);


        final ImageButton imgButton = (ImageButton) findViewById(R.id.floatingActionButton7);
        imgButton.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {


                boolean isFavorite = readState();

                if (isFavorite) {
                    imgButton.setBackgroundResource(R.drawable.ic_favorite_border_black_24dp);
                    isFavorite = false;
                    saveState(isFavorite);
                } else {
                    imgButton.setBackgroundResource(R.drawable.ic_whatshot_black_24dp);
                    isFavorite = true;
                    saveState(isFavorite);

                }
            }
        });
    }


    //  boolean isFavorite = readState();

    // if (isFavorite) {
    //    imgButton.setBackgroundResource(R.drawable.ic_favorite_border_black_24dp);
    //  isFavorite = false;
    //    saveState(isFavorite);
    // } else {
    //    imgButton.setBackgroundResource(R.drawable.ic_whatshot_black_24dp);
    //    isFavorite = true;
    //   saveState(isFavorite);


    private void saveState ( boolean isFavorite){
        SharedPreferences aSharedPreferences = this.getSharedPreferences(
                "Favorite", Context.MODE_PRIVATE);
        SharedPreferences.Editor aSharedPreferencesEdit = aSharedPreferences
                .edit();
        aSharedPreferencesEdit.putBoolean("State", isFavorite);
        aSharedPreferencesEdit.commit();
    }

    private boolean readState () {
        SharedPreferences aSharedPreferences = this.getSharedPreferences(
                "Favorite", Context.MODE_PRIVATE);
        return aSharedPreferences.getBoolean("State", true);
    }

    public void favoritesTitanicFn(View view) {
    }
}
